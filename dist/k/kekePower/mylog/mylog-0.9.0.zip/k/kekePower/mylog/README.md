Usage: mylog3 &lt;TAG&gt; &quot;Your log&quot;
   Or: mylog3 &lt;option&gt; [argument]
Options:
  -v (or myview) - View the changelog
  -s (or mysearch) &lt;search_term&gt; - Search, case insensitive
  -tags - This will show a list of tags you&#039;ve used, sorted alphabetically.