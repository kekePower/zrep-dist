Usage: mylog <TAG> "Your log"
   Or: mylog <option> [argument]
Options:
  -v (or myview) - View the changelog
  -s (or mysearch) <search_term> - Search, case insensitive
  -tags - This will show a list of tags you've used, sorted alphabetically.